return {
'deoplete-plugins/deoplete-clang'
}
