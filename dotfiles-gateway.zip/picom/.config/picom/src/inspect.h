// SPDX-License-Identifier: MPL-2.0
// Copyright (c) 2024 Yuxuan Shui <yshuiv7@gmail.com>

#pragma once
#include <xcb/xcb.h>

int inspect_main(int argc, char **argv, const char *config_file);
